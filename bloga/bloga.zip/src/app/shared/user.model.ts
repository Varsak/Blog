export class User {
// UserName: string;
Password: string;
ConfirmPassword: string;
Email: string;
}
